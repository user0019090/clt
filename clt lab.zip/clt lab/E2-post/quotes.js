const quoteButton = document.getElementById('get-quote-button'); 
const quoteDisplay = document.getElementById('quote-display'); 
 
quoteButton.addEventListener('click', getQuote); 
 
function getQuote() { 
  fetch('https://ron-swanson-quotes.herokuapp.com/v2/quotes') 
    .then(response => response.json())  
    .then(data => { 
      const quote = data[0];  
      quoteDisplay.textContent = quote; 
    }) 
 
    .catch(error => { 
      console.error('Error fetching quote:', error); 
      quoteDisplay.textContent = 'Error: Could not retrieve quote.'; 
    }); 
}