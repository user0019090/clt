const express = require('express');
const { Dropbox } = require('dropbox');
const fetch = require('isomorphic-fetch');
const multer = require('multer');
const upload = multer();
const path = require('path');

const app = express();

app.set('view engine', 'ejs');

const dropbox = new Dropbox({
    accessToken: 'sl.p3GCxhImZyeLB7J90VwnsJWjBoLaa4ALCr-LF09go0vFqA2XFXO0y-imYToT046VBK5GC-IkfzlGQDG00K-cGQBIwPkHuWG0mYu6xz6SHK',
    fetch
});

app.get('/', (req, res) => {
    res.render('index');  
});


app.post('/upload-file', upload.single('file'), (req, res) => {
    const fileContent = req.file.buffer;
    dropbox.filesUpload({ path: `/${req.file.originalname}`, contents: fileContent })
        .then(() => res.send('File uploaded to Dropbox'))
        .catch(err => res.status(500).send(err));
});

app.get('/download-file', (req, res) => {
    const fileName = req.query.fileName;
    dropbox.filesDownload({ path: `/${fileName}` })
        .then(response => {
            res.set({
                'Content-Type': response.result['.tag'] === 'file' ? response.result.name.split('.').pop() : 'application/octet-stream',
                'Content-Disposition': `attachment; filename="${response.result.name}"`
            });
            res.send(response.result.fileBinary);
        })
        .catch(err => res.status(500).send(err));
});

app.listen(3000, () => {
    console.log('Dropbox server is running on port 3000');
});
